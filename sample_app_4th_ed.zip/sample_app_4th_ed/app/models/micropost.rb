class Micropost < ApplicationRecord
  #マイクロポストがユーザーに所属する (belongs_to) 関連付け
  belongs_to :user
  #default_scopeでマイクロポストを順序付ける
  default_scope -> { order(created_at: :desc) }
  # CarrierWaveに画像と関連付けたモデルを伝える
  mount_uploader :picture, PictureUploader
  #user_idの存在性のバリデーションを追加
  validates :user_id, presence: true
  #contentの存在性,文字数のバリデーションを追加
  validates :content, presence: true, length: { maximum: 140 }
  validate  :picture_size

  private

    # アップロードされた画像のサイズをバリデーションする
    def picture_size
      if picture.size > 5.megabytes
        errors.add(:picture, "should be less than 5MB")
      end
    end
end