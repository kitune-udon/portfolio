class PasswordResetsController < ApplicationController
  before_action :get_user,         only: [:edit, :update]
  before_action :valid_user,       only: [:edit, :update]
  before_action :check_expiration, only: [:edit, :update]    # パスワード再設定の有効期限が切れていないかを確認する

  def new
  end

  def create
    # メールアドレスをキーとしてユーザーをデータベースから見つける
    @user = User.find_by(email: params[:password_reset][:email].downcase)
    if @user # データが存在すれば
      @user.create_reset_digest
      @user.send_password_reset_email
      flash[:info] = "Email sent with password reset instructions" # 完了メッセージをセット
      redirect_to root_url # ルートURLにリダイレクト
    else
      flash.now[:danger] = "Email address not found" # エラーメッセージをセット
      render 'new' # newページを出力
    end
  end

  def edit
  end

  def update
    if params[:user][:password].empty? #新しいパスワードが空文字列になっていないか (ユーザー情報の編集ではOKだった)
      @user.errors.add(:password, :blank) #エラーメッセージを追加(新パスワード、空文字チェックNG)
      render 'edit' 
    elsif @user.update_attributes(user_params) #新しいパスワードが正しければ、更新する
      log_in @user #ログイン
      flash[:success] = "Password has been reset." #パスワード更新完了メッセージをセット
      redirect_to @user  #userページにリダイレクト
    else
      render 'edit' #無効なパスワードであれば失敗させる (失敗した理由も表示する)
    end
  end

  private

    def user_params
      params.require(:user).permit(:password, :password_confirmation)
    end

    # Before filters

    def get_user
      #メールアドレスに対応するユーザーを@userインスタンス変数に保存
      @user = User.find_by(email: params[:email])
    end

    # 正しいユーザーかどうか確認する
    #  (ユーザーが存在する、有効化されている、認証済みである) 
    def valid_user
      unless (@user && @user.activated? && #検索、有効化メソッド
              @user.authenticated?(:reset, params[:id]))#認証メソッド
        redirect_to root_url
      end
    end

    # パスワード再設定の有効期限が切れていないかを確認する
    def check_expiration
      if @user.password_reset_expired? #パスワードのリセットが期限切れになった場合はtrueを返します
        flash[:danger] = "Password reset has expired." #処理完了メッセージをセット
        redirect_to new_password_reset_url 
      end
    end
end