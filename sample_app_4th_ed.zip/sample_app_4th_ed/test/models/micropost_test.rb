require 'test_helper'

class MicropostTest < ActiveSupport::TestCase

  def setup
    @user = users(:michael)
    #テストユーザーと紐付けた新しいマイクロポストを作成
    @micropost = @user.microposts.build(content: "Lorem ipsum")
  end
  
  #作成したマイクロポストが有効かどうかをチェック
  test "should be valid" do
    assert @micropost.valid?
  end
  
  #user_idの存在性のバリデーションに対するテストも追加
  test "user id should be present" do
    @micropost.user_id = nil
    assert_not @micropost.valid?
  end
  
  #Micropostモデルのバリデーションに対するテスト(存在性)
  test "content should be present" do
    @micropost.content = "   "
    assert_not @micropost.valid?
  end
  
  #Micropostモデルのバリデーションに対するテスト(文字数)
  test "content should be at most 140 characters" do
    @micropost.content = "a" * 141
    assert_not @micropost.valid?
  end
  
  #マイクロポストの順序付けをテストする
  test "order should be most recent first" do
    #データベース上の最初のマイクロポストが
    #fixture内のマイクロポスト (most_recent) と同じであるか検証
    assert_equal microposts(:most_recent), Micropost.first
  end
end