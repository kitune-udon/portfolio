require 'test_helper'
#Userプロフィール画面に対するテスト
class UsersProfileTest < ActionDispatch::IntegrationTest
  #Applicationヘルパーを読み込み
  include ApplicationHelper

  def setup
    @user = users(:michael)
  end

  test "profile display" do
    get user_path(@user)
    assert_template 'users/show' #プロフィール画面にアクセス
    assert_select 'title', full_title(@user.name) #ページタイトルチェック
    assert_select 'h1', text: @user.name #ユーザー名チェック
    assert_select 'h1>img.gravatar' #Gravatarチェック
    assert_match @user.microposts.count.to_s, response.body #マイクロポストの投稿数チェック
    assert_select 'div.pagination' #ページ分割されたマイクロポスト
    @user.microposts.paginate(page: 1).each do |micropost|
      assert_match micropost.content, response.body #ページ上にマイクロポストの投稿数の存在チェック
    end
  end
end